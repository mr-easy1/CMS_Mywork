import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LandingComponent } from './landing/landing.component';
import { UserLoginComponent } from './user-login/user-login.component';
import { CreateTemplateComponent } from './create-template/create-template.component';
import { ListTemplateComponent } from './list-template/list-template.component';
// import { SourceEditorComponent } from './source-editor/source-editor.component';


const routes: Routes = [
  {path:"login",component:UserLoginComponent},
  {path:"create",component:CreateTemplateComponent},
  // {path:"source",component:SourceEditorComponent},
  {path:"list",component:ListTemplateComponent},
  {path:"**",component:LandingComponent},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
