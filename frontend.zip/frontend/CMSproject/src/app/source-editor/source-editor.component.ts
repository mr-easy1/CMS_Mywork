import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-source-editor',
  templateUrl: './source-editor.component.html',
  styleUrls: ['./source-editor.component.scss']
})
export class SourceEditorComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
