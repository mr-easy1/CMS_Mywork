import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LandingComponent } from './landing/landing.component';
import { UserLoginComponent } from './user-login/user-login.component';
import { CreateTemplateComponent } from './create-template/create-template.component';
import { ListTemplateComponent } from './list-template/list-template.component';
import { HeaderComponent } from './header/header.component';
import { SourceEditorComponent } from './source-editor/source-editor.component';
import { HttpClientModule } from '@angular/common/http';

@NgModule({
  declarations: [
    AppComponent,
    LandingComponent,
    UserLoginComponent,
    CreateTemplateComponent,
    ListTemplateComponent,
    HeaderComponent,
    SourceEditorComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
